<html>
<head>
<title>Adicionar</title>
<meta charset = 'utf-8'/>
<body>
<!DOCTYPE html>
<h1>Agencia de Veículos -SCAV</<h1>
<hr>
<a href="menu.html">Inicio</a> | <a href = "adicionar"